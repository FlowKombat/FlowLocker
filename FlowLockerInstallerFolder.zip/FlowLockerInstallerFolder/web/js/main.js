eel.expose(changeStatus);
function changeStatus(taskid, status, color) {
    document.getElementById('status'+taskid).innerHTML = status;
    document.getElementById('status'+taskid).style.color = color
}

eel.expose(error);
function error(error) {
    Swal.fire({type:'error', title:'Bruh', text:error, background:'linear-gradient(326.19deg, #C2E9FB 8.25%, #A1C4FD 91.76%)'});
}

eel.expose(reload);
function reload() {
    location.reload();
}

eel.expose(changeName);
function changeName(taskid, name) {
    document.getElementById('name'+taskid).innerHTML = name;
}

function startTask(taskid) {
    eel.start_task(taskid)
}

function startAll() {
    eel.start_all()
}

function deleteAll() {
    eel.delete_all()
    location.reload();
}

function delTask(taskid) {
    eel.delete_task(taskid)
    location.reload();
}

function dupTask(taskid) {
    eel.duplicate_task(taskid)
    location.reload();
}

function createTasks() {
    var sku = document.getElementById('pid/url sel').value
    if (sku == '') {
        Swal.fire({type:'error', title:'Bruh', text:'Please  insert  PID/URL', background:'linear-gradient(326.19deg, #C2E9FB 8.25%, #A1C4FD 91.76%)'});
        return;
    }
    var size = document.getElementById('size sel').value
    if (size == '') {
        Swal.fire({type:'error', title:'Bruh', text:'Please  select  size', background:'linear-gradient(326.19deg, #C2E9FB 8.25%, #A1C4FD 91.76%)'});
        return;
    }
    var region = document.getElementById('store sel').value
    if (region == '') {
        Swal.fire({type:'error', title:'Bruh', text:'Please  select  the  store', background:'linear-gradient(326.19deg, #C2E9FB 8.25%, #A1C4FD 91.76%)'});
        return;
    }
    var mode = document.getElementById('payment sel').value
    if (mode == '') {
        Swal.fire({type:'error', title:'Bruh', text:'Please  select  mode', background:'linear-gradient(326.19deg, #C2E9FB 8.25%, #A1C4FD 91.76%)'});
        return;
    }
    var proxylist = document.getElementById('proxy sel').value
    var qty = document.getElementById('qty sel').value
    if (qty == '') {
        Swal.fire({type:'error', title:'Bruh', text:'Please  insert  quantity', background:'linear-gradient(326.19deg, #C2E9FB 8.25%, #A1C4FD 91.76%)'});
        return;
    }
    if (isNaN(qty)) {
        Swal.fire({type:'error', title:'Bruh', text:'Please  a  valid  quantity', background:'linear-gradient(326.19deg, #C2E9FB 8.25%, #A1C4FD 91.76%)'});
        return;
    }
    var profile = document.getElementById('profile sel').value
    eel.create_task(region, sku, size, proxylist, profile, mode, qty)
    Swal.fire({type:'success', title:'Congratulations!', text:qty + '  task(s)  succesfully  created!', background:'linear-gradient(326.19deg, #C2E9FB 8.25%, #A1C4FD 91.76%)'})
}

function delProxylist(name) {
    eel.delete_proxylist(name)
    location.reload();
}

function createProxylist() {
    var name = document.getElementById('proxy input').value
    if (name == '') {
        Swal.fire({type:'error', title:'Bruh', text:'Please  insert  name', background:'linear-gradient(326.19deg, #C2E9FB 8.25%, #A1C4FD 91.76%)'});
        return;
    }
    var proxylist = document.getElementById('proxy tab').value
    if (proxylist == '') {
        Swal.fire({type:'error', title:'Bruh', text:'Please  insert proxylist', background:'linear-gradient(326.19deg, #C2E9FB 8.25%, #A1C4FD 91.76%)'});
        return;
    }
    eel.create_proxylist(name, proxylist)
    location.reload();
}

function delProfile(name) {
    eel.delete_profile(name)
    location.reload();
}

function createProfile() {
    var profilename = document.getElementById('profile name input').value
    if (profilename == '') {
        Swal.fire({type:'error', title:'Bruh', text:'Please  insert  profile  name', background:'linear-gradient(326.19deg, #C2E9FB 8.25%, #A1C4FD 91.76%)'});
        return;
    }
    var name = document.getElementById('name input').value
    var surname = document.getElementById('surname input').value
    var email = document.getElementById('email input').value
    var address = document.getElementById('address input').value
    var address2 = document.getElementById('address 2 input').value
    var house = document.getElementById('house input').value
    var city = document.getElementById('city input').value
    var zipcode = document.getElementById('zipcode input').value
    var state = document.getElementById('state input').value
    var phone = document.getElementById('phone input').value
    var cholder = document.getElementById('card holder input').value
    var cnumber = document.getElementById('card number input').value
    var cexpiry = document.getElementById('card expiry input').value
    var ccvc = document.getElementById('card cvc input').value
    var birthday = document.getElementById('birthday input').value
    eel.create_profile(profilename, name, surname, email, address, address2, house, city, zipcode, state, phone, cholder, cnumber, cexpiry, ccvc, birthday);
    Swal.fire({type:'success', title:'Congratulations!', text:profilename + '  succesfully  created!', background:'linear-gradient(326.19deg, #C2E9FB 8.25%, #A1C4FD 91.76%)'})
}

function testWebhook() {
    var webhook = document.getElementById('webhook input').value
    if (webhook == '') {
        Swal.fire({type:'error', title:'Bruh', text:'Please  insert  webhook', background:'linear-gradient(326.19deg, #C2E9FB 8.25%, #A1C4FD 91.76%)'});
        return;
    }
    eel.test_webhook(webhook);
}

function setDelay() {
    var delay = document.getElementById('delay input').value
    eel.set_delay(delay);
}

function startGeneration() {
    var region = document.getElementById('cookie store sel').value
    if (region == '') {
        Swal.fire({type:'error', title:'Bruh', text:'Please  select  the  store', background:'linear-gradient(326.19deg, #C2E9FB 8.25%, #A1C4FD 91.76%)'});
        return;
    }
    var proxylist = document.getElementById('cookie proxy sel').value
    eel.cookie_generation(region, proxylist)
}

function clearAll() {
    eel.clear_all()
    Swal.fire({type:'success', text:'All cookies were deleted', background:'linear-gradient(326.19deg, #C2E9FB 8.25%, #A1C4FD 91.76%)'});
}