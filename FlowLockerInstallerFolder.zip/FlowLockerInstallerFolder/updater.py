import cfscrape, sys, os
from wget import download
from datetime import datetime
from colorama import Fore, init
from time import sleep

def now():
    now = '[{}] '.format((str(datetime.now())))
    return now

class updater():

    def __init__(self, version):
        self.version = version

    def update(self):
        s = cfscrape.create_scraper()

        link = s.get('https://pastebin.com/raw/SiDShcNa').text

        if link.split('-')[2] != self.version:
            print (now() + Fore.GREEN + '[STATUS] Update avaible!')
            download(link.split('-')[3], 'FlowLocker-new.exe')
            os.rename('FlowLocker.exe', 'FlowLocker-old.exe')
            sleep(0.5)
            os.rename('FlowLocker-new.exe', 'FlowLocker.exe')
            sleep(0.5)
            os.startfile('FlowLocker.exe')
            sleep(2)
            sys.exit()

