import eel, requests, json, threading, datetime, time, random, driver, os, zipfile
from authentication import authentication
from updater import updater
from colorama import Fore, init
from discord_webhook import DiscordEmbed, DiscordWebhook
from bs4 import BeautifulSoup
from selenium import webdriver
init(convert=True, autoreset=True)
version = '0.0.1'

try:
    os.remove('FlowLocker-old.exe')
except:
    pass

flowlocker = '''
 ███████╗██╗      ██████╗ ██╗    ██╗    ██╗      ██████╗  ██████╗██╗  ██╗███████╗██████╗ 
 ██╔════╝██║     ██╔═══██╗██║    ██║    ██║     ██╔═══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗
 █████╗  ██║     ██║   ██║██║ █╗ ██║    ██║     ██║   ██║██║     █████╔╝ █████╗  ██████╔╝
 ██╔══╝  ██║     ██║   ██║██║███╗██║    ██║     ██║   ██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗
 ██║     ███████╗╚██████╔╝╚███╔███╔╝    ███████╗╚██████╔╝╚██████╗██║  ██╗███████╗██║  ██║
 ╚═╝     ╚══════╝ ╚═════╝  ╚══╝╚══╝     ╚══════╝ ╚═════╝  ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝\n'''
print (Fore.CYAN + flowlocker)
config = json.load(open('web\\json\\config.json'))
key = config['key']
authentication(key).auth()
updater(version).update()

eel.init('web')

yellow = '#ffe600'
red = '#ff0000'
green = '#00cc47'
white = '#ffffff'

all_tasks = json.load(open('web\\json\\tasks.json'))
for task in all_tasks:
    task['name'] = ''
    task['color'] = '#ffffff'
    task['status'] = 'Idle'
with open('web\\json\\tasks.json', 'w') as c:
    json.dump(all_tasks, c, indent=4)

def color(color=None, status=None, name=None, taskid=None):
    eel.changeStatus(taskid, status, color)
def name(color=None, status=None, name=None, taskid=None):
    eel.changeName(taskid, name)

main_headers = {
    'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-encoding':'gzip, deflate, br',
    'accept-language':'it-IT,it;q=0.9,en-US;q=0.8,en;q=0.7',
    'upgrade-insecure-requests':'1',
    'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36'
}

addtocart_headers = {
    'accept':'application/json, text/javascript, */*; q=0.01',
    'accept-encoding':'gzip, deflate, br',
    'accept-language':'it-IT,it;q=0.9,en-US;q=0.8,en;q=0.7',
    'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36',
    'x-requested-with':'XMLHttpRequest'
}

profiles = json.load(open('web\\json\\profiles.json'))
proxies = json.load(open('web\\json\\proxies.json'))
config = json.load(open('web\\json\\config.json'))
webhook_url = config['webhook']

def now():
    now = str(datetime.datetime.now())
    now = '[' + now + ']'
    return now

def main(taskid=None):
    profiles = json.load(open('web\\json\\profiles.json'))
    proxies = json.load(open('web\\json\\proxies.json'))
    config = json.load(open('web\\json\\config.json'))
    webhook_url = config['webhook']

    def private_webhook(region, taskid, image, title, price, sku, size, mode, checkurl=''):
        try:
            webhook = DiscordWebhook(url=webhook_url)
            embed = DiscordEmbed(title='FlowLocker Success', color=59435)
            embed.add_embed_field(name='Region', value=region.upper(), inline=False)
            embed.add_embed_field(name='Task', value=taskid.replace('TASK ', ''), inline=False)
            embed.set_thumbnail(url=image)
            embed.add_embed_field(name='Product', value=title, inline=False)
            embed.add_embed_field(name='Price', value=price, inline=False)
            embed.add_embed_field(name='Variant/Url', value=sku, inline=False)
            embed.add_embed_field(name='Size', value=size, inline=False)
            embed.add_embed_field(name='Mode', value=mode.upper(), inline=False)
            if mode == 'discord':
                embed.add_embed_field(name='Checkout', value='[Click here for checkout](' + checkurl + ')', inline=False)
            embed.set_footer(text='Flow Locker | {}'.format(str(datetime.datetime.now())), icon_url='https://cdn.discordapp.com/attachments/654359760430170130/655535475947208704/static_logo.png')
            webhook.add_embed(embed)
            webhook.execute()

        except Exception as e:
            print (now() + Fore.RED + ' [TASK ' + taskid + '] [ERROR] Private Webhook error -> ' + str(e))
            tasks = json.load(open('web\\json\\tasks.json'))
            task = tasks[int(taskid)]
            task['color'] = red
            task['status'] = 'Webhook error'
            with open('web\\json\\tasks.json', 'w') as c:
                json.dump(tasks, c, indent=4)

            color(taskid=taskid, color=red, status='Webhook error')

    def public_success(region, taskid, image, title, price, sku, size, mode):
        try:
            webhook = DiscordWebhook(url='https://discordapp.com/api/webhooks/657961361258577923/9vgIpGrdFMe6Qy6Rz7amaTXUh7g_dnZmpd5a6BhEJkrg_QL09tN7Pb1zSY5aFrpxeNV2')
            embed = DiscordEmbed(title='FlowLocker Success', color=3158326)
            embed.add_embed_field(name='Region', value=region.upper(), inline=False)
            embed.add_embed_field(name='Task', value=taskid.replace('TASK ', ''), inline=False)
            embed.set_thumbnail(url=image)
            embed.add_embed_field(name='Product', value=title, inline=False)
            embed.add_embed_field(name='Price', value=price, inline=False)
            embed.add_embed_field(name='Variant/Url', value=sku, inline=False)
            embed.add_embed_field(name='Size', value=size, inline=False)
            embed.add_embed_field(name='Mode', value=mode.upper(), inline=False)
            embed.set_footer(text='Flow Locker | {}'.format(str(datetime.datetime.now())), icon_url='https://cdn.discordapp.com/attachments/654359760430170130/655535475947208704/static_logo.png')
            webhook.add_embed(embed)
            webhook.execute()

        except Exception as e:
            print (now() + Fore.RED + ' [TASK ' + taskid + '] [ERROR] Public Webhook error -> ' + str(e))
            tasks = json.load(open('web\\json\\tasks.json'))
            task = tasks[int(taskid)]
            task['color'] = red
            task['status'] = 'Webhook error'
            with open('web\\json\\tasks.json', 'w') as c:
                json.dump(tasks, c, indent=4)

            color(taskid=taskid, color=red, status='Webhook error')

    def choose_proxy(proxylist, taskid):
        try:
            total_proxies = proxies[proxylist]
            proxy = random.choice(total_proxies)

            if len(proxy.split(':')) == 2:

                proxy = {
                'http': 'http://' + proxy,
                'https': 'http://' + proxy
                }

            elif len(proxy.split(':')) == 4:

                prx = proxy.split(':')

                proxy = {
                'http': 'http://' + prx[2] + ':' + prx[3] + '@' + prx[0] + ':' + prx[1],
                'https': 'https://' + prx[2] + ':' + prx[3] + '@' + prx[0] + ':' + prx[1]
                }

            return proxy

        except Exception as e:
            print (now() + Fore.RED + ' [TASK ' + taskid + '] [ERROR] Picking proxy error -> ' + str(e))
            tasks = json.load(open('web\\json\\tasks.json'))
            task = tasks[int(taskid)]
            task['color'] = red
            task['status'] = 'Cookie error'
            with open('web\\json\\tasks.json', 'w') as c:
                json.dump(tasks, c, indent=4)
            color(taskid=taskid, color=red, status='Cookie error')
            time.sleep(5)
            choose_proxy(proxylist, taskid)

    def choose_cookie(region, taskid):
        try:
            cookies = json.load(open('web\\json\\cookies.json'))
            cookieslist = cookies[region]

            if len(cookieslist) == 0:
                print (now() + Fore.RED + ' [TASK ' + taskid + '] [ERROR] No cookies loaded')
                tasks = json.load(open('web\\json\\tasks.json'))
                task = tasks[int(taskid)]
                task['color'] = red
                task['status'] = 'No cookies loaded'
                with open('web\\json\\tasks.json', 'w') as c:
                    json.dump(tasks, c, indent=4)
                color(taskid=taskid, color=red, status='No cookies loaded')
                time.sleep(5)
                choose_cookie(region, taskid)

            else:
                cookie = cookieslist[0]
                cookieslist.remove(cookie)
                with open('web\\json\\cookies.json', 'w') as c:
                    json.dump(cookies, c, indent=4)

                cookies = requests.cookies.RequestsCookieJar()
                cookies.set(domain='.footlocker.' + region, name= '_abck', path= '/', secure=True, value=cookie)

                return cookies

        except Exception as e:
            print (now() + Fore.RED + ' [TASK ' + taskid + '] [ERROR] Picking cookie error -> ' + str(e))
            tasks = json.load(open('web\\json\\tasks.json'))
            task = tasks[int(taskid)]
            task['color'] = red
            task['status'] = 'Cookie error'
            with open('web\\json\\tasks.json', 'w') as c:
                json.dump(tasks, c, indent=4)
            color(taskid=taskid, color=red, status='Cookie error')
            time.sleep(5)
            choose_cookie(region, taskid)

    def cop(taskid, region, sku, size, proxylist, profilo, mode):

        if json.load(open('web\\json\\config.json'))['delay'] == '':
            delay = 10
        try:
            s = requests.Session()

            def tester():
                print (now() + Fore.YELLOW + ' [TASK ' + taskid + '] [STATUS] Checking proxy...')
                tasks = json.load(open('web\\json\\tasks.json'))
                task = tasks[int(taskid)]
                task['color'] = yellow
                task['status'] = 'Checking proxy...'
                with open('web\\json\\tasks.json', 'w') as c:
                    json.dump(tasks, c, indent=4)
                color(taskid=taskid, color=yellow, status='Checking proxy...')
                s.proxies = choose_proxy(proxylist, taskid)
                try:
                    test = s.get('https://www.footlocker.' + region, headers=main_headers)
                    if test.status_code in (302, 200, 503, 201):
                        print (now() + Fore.GREEN + ' [TASK ' + taskid + '] [STATUS] Working proxy!')
                        tasks = json.load(open('web\\json\\tasks.json'))
                        task = tasks[int(taskid)]
                        task['color'] = green
                        task['status'] = 'Working proxy!'
                        with open('web\\json\\tasks.json', 'w') as c:
                            json.dump(tasks, c, indent=4)
                        color(taskid=taskid, color=green, status='Working proxy')
                    else:
                        print (now() + Fore.RED + ' [TASK ' + taskid + '] [ERROR] Not working proxy!')
                        tasks = json.load(open('web\\json\\tasks.json'))
                        task = tasks[int(taskid)]
                        task['color'] = red
                        task['status'] = 'Not working'
                        with open('web\\json\\tasks.json', 'w') as c:
                            json.dump(tasks, c, indent=4)
                        color(taskid=taskid, color=red, status='Proxy error')
                        tester()

                except Exception as e:
                    print (now() + Fore.RED + ' [TASK ' + taskid + '] [ERROR] Not working proxy -> ' + str(e))
                    tasks = json.load(open('web\\json\\tasks.json'))
                    task = tasks[int(taskid)]
                    task['color'] = red
                    task['status'] = 'Proxy error'
                    with open('web\\json\\tasks.json', 'w') as c:
                        json.dump(tasks, c, indent=4)
                    color(taskid=taskid, color=red, status='Proxy error')
                    tester()


            s.cookies = choose_cookie(region, taskid)

            def card(title='Not avaible', price='Not avaible', image='https://cdn.discordapp.com/attachments/654359760430170130/655535475947208704/static_logo.png', checkurl=None):
                profile = profiles[profilo]

                cholder = profile['cholder']
                cnumber = profile['cnumber']
                cmonth = profile['cexpiry'].split('/')[0]
                cyear = profile['cexpiry'].split('/')[1]
                ccvc = profile['ccvc']

                print (now() + Fore.YELLOW + ' [TASK ' + taskid + '] [STATUS] Opening Checkout...')
                tasks = json.load(open('web\\json\\tasks.json'))
                task = tasks[int(taskid)]
                task['color'] = yellow
                task['status'] = 'Opening checkout'
                with open('web\\json\\tasks.json', 'w') as c:
                    json.dump(tasks, c, indent=4)
                color(taskid=taskid, color=yellow, status='Opening checkout')
                if proxylist != '':
                    total_proxies = proxies[proxylist]
                    browser = driver.driver(proxylist=total_proxies, region=region)
                else:
                    browser = driver.driver(region=region)
                try:
                    os.remove('Proxy1.zip')
                except:
                    pass
                browser.get(checkurl)
                print (now() + Fore.YELLOW + ' [TASK ' + taskid + '] [STATUS] Submitting card info...')
                tasks = json.load(open('web\\json\\tasks.json'))
                task = tasks[int(taskid)]
                task['color'] = yellow
                task['status'] = 'Submitting card info...'
                with open('web\\json\\tasks.json', 'w') as c:
                    json.dump(tasks, c, indent=4)
                color(taskid=taskid, color=yellow, status='Submitting card info...')
                browser.find_element_by_xpath('//*[@id="paymentMethods"]/li[1]/input').click()
                time.sleep(2)
                browser.find_element_by_xpath('//*[@id="card.cardNumber"]').send_keys(cnumber)
                browser.find_element_by_xpath('//*[@id="card.cardHolderName"]').send_keys(cholder.replace('+', ' '))
                browser.find_element_by_xpath('//*[@id="card.expiryMonth"]').send_keys(cmonth)
                browser.find_element_by_xpath('//*[@id="card.expiryYear"]').send_keys(cyear)
                browser.find_element_by_xpath('//*[@id="card.cvcCode"]').send_keys(ccvc)
                time.sleep(1)
                browser.find_element_by_xpath('//*[@id="pmmdetails-card"]/table/tbody/tr[7]/td/div/input').click()
                print (now() + Fore.GREEN + ' [TASK ' + taskid + '] [SUCCESS] Succesfully checked out!')
                tasks = json.load(open('web\\json\\tasks.json'))
                task = tasks[int(taskid)]
                task['color'] = green
                task['status'] = 'Success!'
                with open('web\\json\\tasks.json', 'w') as c:
                    json.dump(tasks, c, indent=4)
                color(taskid=taskid, color=green, status='Success!')
                private_webhook(region, taskid, image, title, price, sku, size, mode)
                public_success(region, taskid, image, title, price, sku, size, mode)
                input()

            def paypal(title='Not avaible', price='Not avaible', image='https://cdn.discordapp.com/attachments/654359760430170130/655535475947208704/static_logo.png', checkurl=None):
                print (now() + Fore.YELLOW + ' [TASK ' + taskid + '] [STATUS] Opening Checkout...')
                tasks = json.load(open('web\\json\\tasks.json'))
                task = tasks[int(taskid)]
                task['color'] = yellow
                task['status'] = 'Opening checkout'
                with open('web\\json\\tasks.json', 'w') as c:
                    json.dump(tasks, c, indent=4)
                color(taskid=taskid, color=yellow, status='Opening checkout')
                if proxylist != '':
                    total_proxies = proxies[proxylist]
                    browser = driver.driver(proxylist=total_proxies, region=region)
                else:
                    browser = driver.driver(region=region)
                try:
                    os.remove('Proxy1.zip')
                except:
                    pass
                browser.get(checkurl)
                browser.find_element_by_xpath('//*[@id="paymentMethods"]/li[2]/input').click()
                time.sleep(2)
                browser.find_element_by_xpath('//*[@id="pmmdetails-paypal"]/table/tbody/tr[2]/td/div/input').click()
                private_webhook(region, taskid, image, title, price, sku, size, mode)
                public_success(region, taskid, image, title, price, sku, size, mode)
                print (now() + Fore.GREEN + ' [TASK ' + taskid + '] [SUCCESS] PayPal opened!')
                tasks = json.load(open('web\\json\\tasks.json'))
                task = tasks[int(taskid)]
                task['color'] = green
                task['status'] = 'Success!'
                with open('web\\json\\tasks.json', 'w') as c:
                    json.dump(tasks, c, indent=4)
                color(taskid=taskid, color=green, status='Success!')
                input()
                

            def ship(title='Not avaible', price='Not avaible', image='https://cdn.discordapp.com/attachments/654359760430170130/655535475947208704/static_logo.png'):
                try:
                    cart = s.get('https://www.footlocker.' + region + '/en/cart', headers=main_headers)
                    soup = BeautifulSoup(cart.text, 'html.parser')
                    try:
                        SynchronizerToken = soup.find('input', {'name':'SynchronizerToken'})['value']
                    except:
                        try:
                            page = s.get('https://www.footlocker.' + region, headers=main_headers)
                            soup = BeautifulSoup(page.text, 'html.parser')
                            try:
                                SynchronizerToken = soup.find('input', {'name':'SynchronizerToken'})['value']
                            except Exception as e:
                                print (now() + Fore.RED + ' [TASK ' + taskid + '] [ERROR] Token error -> ' + str(e))
                                tasks = json.load(open('web\\json\\tasks.json'))
                                task = tasks[int(taskid)]
                                task['color'] = red
                                task['status'] = 'Token error'
                                with open('web\\json\\tasks.json', 'w') as c:
                                    json.dump(tasks, c, indent=4)
                                color(taskid=taskid, color=red, status='Token error')
                                start()

                        except Exception as e:
                            print (now() + Fore.RED + ' [TASK ' + taskid + '] [ERROR] Token error -> ' + str(e))
                            tasks = json.load(open('web\\json\\tasks.json'))
                            task = tasks[int(taskid)]
                            task['color'] = red
                            task['status'] = 'Token error'
                            with open('web\\json\\tasks.json', 'w') as c:
                                json.dump(tasks, c, indent=4)
                            color(taskid=taskid, color=red, status='Token error')
                            start()

                    base = soup.find('span', {'data-lazyloading-content-handler':'miniCartLazyLoadingJSONContentHandler'})['data-request'].replace('ViewMiniCart-Lazyload', '')
                    s.get(base + 'ViewCart-Checkout?SynchronizerToken=' + SynchronizerToken, headers=main_headers)
                    shipurl = s.get('https://www.footlocker.' + region + '/en/checkout-overview?SynchronizerToken=' + SynchronizerToken, headers=main_headers, allow_redirects=True).url
                    shipage = s.get(shipurl, headers=main_headers)
                    soup = BeautifulSoup(shipage.text, 'html.parser')
                    try:
                        PaymentServiceSelection = soup.find('input', {'name':'PaymentServiceSelection'})['value']
                    except:
                        PaymentServiceSelection = ''
                    try:
                        ShippingMethodUUID = soup.find('input', {'name':'ShippingMethodUUID'})['value']
                    except:
                        ShippingMethodUUID = ''
                    try:
                        shipping_AddressID = soup.find('input', {'name':'shipping_AddressID'})['value']
                    except:
                        shipping_AddressID = ''

                    profile = profiles[profilo]
                    try:
                        name = profile['name']
                        surname = profile['surname']
                        state = profile['state']
                        address = profile['address']
                        house = profile['house']
                        address2 = profile['address2']
                        city = profile['city']
                        zipcode = profile['zipcode']
                        phone = profile['phone']
                        bday = profile['birthday'].split('/')[0]
                        bmonth = profile['birthday'].split('/')[1]
                        byear = profile['birthday'].split('/')[2]
                        email = profile['email']
                    except Exception as e:
                        print (now() + Fore.RED + ' [TASK ' + taskid + '] [ERROR] Reading profile error -> ' + str(e))
                        tasks = json.load(open('web\\json\\tasks.json'))
                        task = tasks[int(taskid)]
                        task['color'] = red
                        task['status'] = 'Profile error'
                        with open('web\\json\\tasks.json', 'w') as c:
                            json.dump(tasks, c, indent=4)
                        color(taskid=taskid, color=red, status='Profile error')
                        start()

                    shipayload = {
                    'SynchronizerToken':SynchronizerToken,
                    'isshippingaddress':'',
                    'billing_Title':'common.account.salutation.mr.text',
                    'billing_FirstName':name,
                    'billing_LastName':surname,
                    'billing_CountryCode':state,
                    'billing_Address1':address,
                    'billing_Address2':house,
                    'billing_Address3':address2,
                    'billing_City':city,
                    'billing_PostalCode':zipcode,
                    'billing_PhoneHome':phone,
                    'billing_BirthdayRequired':'true',
                    'billing_Birthday_Day':bday,
                    'billing_Birthday_Month':bmonth,
                    'billing_Birthday_Year':byear,
                    'email_Email':email,
                    'billing_ShippingAddressSameAsBilling':'true',
                    'shipping_Title':'common.account.salutation.mr.text',
                    'shipping_FirstName':'',
                    'shipping_LastName':'',
                    'SearchTerm':'',
                    'shipping_CountryCode':state,
                    'shipping_Address1'	:'',
                    'shipping_Address2'	:'',
                    'shipping_Address3':'',
                    'shipping_City':'',
                    'shipping_PostalCode':'',
                    'shipping_PhoneHome':'',
                    'shipping_AddressID':shipping_AddressID,
                    'CheckoutRegisterForm_Password':'',
                    'promotionCode':'',
                    'PaymentServiceSelection':PaymentServiceSelection,
                    'UserDeviceTypeForPaymentRedirect':'Dekstop',
                    'UserDeviceFingerprintForPaymentRedirect':'',
                    'ShippingMethodUUID':ShippingMethodUUID,
                    'termsAndConditions':'on',
                    'GDPRDataComplianceRequired':'true',
                    'sendOrder':''
                    }

                    print (now() + Fore.YELLOW + ' [TASK ' + taskid + '] [STATUS] Submitting shipping info...')
                    tasks = json.load(open('web\\json\\tasks.json'))
                    task = tasks[int(taskid)]
                    task['color'] = yellow
                    task['status'] = 'Submitting shipping info...'
                    with open('web\\json\\tasks.json', 'w') as c:
                        json.dump(tasks, c, indent=4)
                    color(taskid=taskid, color=yellow, status='Submitting shipping info...')
                    ship = s.post(base + 'ViewCheckoutOverview-Dispatch?SynchronizerToken=' + SynchronizerToken, headers=addtocart_headers, data=shipayload, allow_redirects=True)

                    if ship.status_code == 403 or 'denied' in ship.text:
                        print (now() + Fore.RED + ' [TASK ' + taskid + '] [ERROR] Access denied')
                        tasks = json.load(open('web\\json\\tasks.json'))
                        task = tasks[int(taskid)]
                        task['color'] = red
                        task['status'] = 'Access denied'
                        with open('web\\json\\tasks.json', 'w') as c:
                            json.dump(tasks, c, indent=4)
                        color(taskid=taskid, color=red, status='Access denied')
                        s.cookies = choose_cookie(region, taskid)
                        start()

                    elif 'BarclaycardSmartpayRedirectForm' in ship.text:
                        print (now() + Fore.GREEN + ' [TASK ' + taskid + '] [STATUS] Succesfully added ship!')
                        tasks = json.load(open('web\\json\\tasks.json'))
                        task = tasks[int(taskid)]
                        task['color'] = green
                        task['status'] = 'Succesfully added ship!'
                        with open('web\\json\\tasks.json', 'w') as c:
                            json.dump(tasks, c, indent=4)
                        color(taskid=taskid, color=green, status='Succesfully added ship!')
                        checkurl = ship.url
                        if mode == 'discord':
                            private_webhook(region, taskid, image, title, price, sku, size, mode, checkurl=checkurl)
                            public_success(region, taskid, image, title, price, sku, size, mode)
                            print (now() + Fore.GREEN + ' [TASK ' + taskid + '] [SUCCESS] Check webhook for checkout!')
                            tasks = json.load(open('web\\json\\tasks.json'))
                            task = tasks[int(taskid)]
                            task['color'] = green
                            task['status'] = 'Success!'
                            with open('web\\json\\tasks.json', 'w') as c:
                                json.dump(tasks, c, indent=4)
                            color(taskid=taskid, color=green, status='Success!')
                            input()
                        elif mode == 'card':
                            card(title='Not avaible', price='Not avaible', image='https://cdn.discordapp.com/attachments/654359760430170130/655535475947208704/static_logo.png', checkurl=checkurl)
                        elif mode == 'paypal':
                            paypal(title='Not avaible', price='Not avaible', image='https://cdn.discordapp.com/attachments/654359760430170130/655535475947208704/static_logo.png', checkurl=checkurl)

                    else:
                        print (now() + Fore.RED + ' [TASK ' + taskid + '] [ERROR] Error adding ship')
                        tasks = json.load(open('web\\json\\tasks.json'))
                        task = tasks[int(taskid)]
                        task['color'] = red
                        task['status'] = 'Ship error'
                        with open('web\\json\\tasks.json', 'w') as c:
                            json.dump(tasks, c, indent=4)
                        color(taskid=taskid, color=red, status='Ship error')
                        ship()

                except Exception as e:
                    print (now() + Fore.RED + ' [TASK ' + taskid + '] [ERROR] Shipping error -> ' + str(e))
                    tasks = json.load(open('web\\json\\tasks.json'))
                    task = tasks[int(taskid)]
                    task['color'] = red
                    task['status'] = 'Ship error'
                    with open('web\\json\\tasks.json', 'w') as c:
                        json.dump(tasks, c, indent=4)
                    color(taskid=taskid, color=red, status='Ship error')
                    start()

            def only_atc(title='Not avaible', price='Not avaible', image='https://cdn.discordapp.com/attachments/654359760430170130/655535475947208704/static_logo.png'):
                print (now() + Fore.YELLOW + ' [TASK ' + taskid + '] [STATUS] Opening Footlocker...')
                tasks = json.load(open('web\\json\\tasks.json'))
                task = tasks[int(taskid)]
                task['color'] = yellow
                task['status'] = 'Opening Footlocker'
                with open('web\\json\\tasks.json', 'w') as c:
                    json.dump(tasks, c, indent=4)
                color(taskid=taskid, color=yellow, status='Opening Footlocker')
                if proxylist != '':
                    total_proxies = proxies[proxylist]
                    browser = driver.driver(proxylist=total_proxies, region=region)
                else:
                    browser = driver.driver(region=region)
                try:
                    os.remove('Proxy1.zip')
                except:
                    pass
                browser.get('https://www.footlocker.' + region)
                print (now() + Fore.YELLOW + ' [TASK ' + taskid + '] [STATUS] Adding cookies...')
                tasks = json.load(open('web\\json\\tasks.json'))
                task = tasks[int(taskid)]
                task['color'] = yellow
                task['status'] = 'Adding cookies...'
                with open('web\\json\\tasks.json', 'w') as c:
                    json.dump(tasks, c, indent=4)
                color(taskid=taskid, color=yellow, status='Adding cookies...')
                browser.delete_all_cookies()
                for c in s.cookies:
                    z = {'name':c.name,
                            'value':c.value,
                            'path':c.path}
                    browser.add_cookie(z)
                print (now() + Fore.YELLOW + ' [TASK ' + taskid + '] [STATUS] Opening cart...')
                tasks = json.load(open('web\\json\\tasks.json'))
                task = tasks[int(taskid)]
                task['color'] = yellow
                task['status'] = 'Opening cart...'
                with open('web\\json\\tasks.json', 'w') as c:
                    json.dump(tasks, c, indent=4)
                color(taskid=taskid, color=yellow, status='Opening cart...')
                browser.get('https://www.footlocker.' + region + '/en/cart')
                private_webhook(region, taskid, image, title, price, sku, size, mode)
                public_success(region, taskid, image, title, price, sku, size, mode)
                print (now() + Fore.GREEN + ' [TASK ' + taskid + '] [SUCCESS] Cart opened!')
                tasks = json.load(open('web\\json\\tasks.json'))
                task = tasks[int(taskid)]
                task['color'] = green
                task['status'] = 'Cart opened'
                with open('web\\json\\tasks.json', 'w') as c:
                    json.dump(tasks, c, indent=4)
                color(taskid=taskid, color=green, status='Success!')
                input()

            def add_to_cart(variant_base, size, title='Not avaible', price='Not avaible', image='https://cdn.discordapp.com/attachments/654359760430170130/655535475947208704/static_logo.png'):
                try:
                    if size == 'RANDOM':
                        is_random = True
                    else:
                        is_random = False

                    if is_random == True:
                        sizelist = ['4', '4.5', '5', '5.5', '6', '6.5', '7', '7.5', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12', '12.5']
                        size = random.choice(sizelist)

                    if len(size) == 1:
                        variant = variant_base + '0' + size + '0'
                    elif len(size) == 2:
                        variant = variant_base + size + '0'
                    elif len(size) == 3:
                        variant = variant_base + '0' + size.replace('.', '')
                    elif len(size) == 4:
                        variant = variant_base + size.replace('.', '')

                    payload = {
                        'isOYS':'1',
                        'Quantity':'1',
                        'JumpTarget':'ViewCheckoutOverview-Start',
                        'SKU':variant
                    }

                    print (now() + Fore.YELLOW + ' [TASK ' + taskid + '] [STATUS] Adding to cart...')
                    tasks = json.load(open('web\\json\\tasks.json'))
                    task = tasks[int(taskid)]
                    task['color'] = yellow
                    task['status'] = 'Adding to cart...'
                    with open('web\\json\\tasks.json', 'w') as c:
                        json.dump(tasks, c, indent=4)
                    color(taskid=taskid, color=yellow, status='Adding to cart...')

                    atc_post = s.post('https://www.footlocker.' + region + '/en/addtocart', headers=addtocart_headers, data=payload)

                    if atc_post.status_code == 403 or 'denied' in atc_post.text:
                        print (now() + Fore.RED + ' [TASK ' + taskid + '] [ERROR] Access denied')
                        tasks = json.load(open('web\\json\\tasks.json'))
                        task = tasks[int(taskid)]
                        task['color'] = red
                        task['status'] = 'Access denied'
                        with open('web\\json\\tasks.json', 'w') as c:
                            json.dump(tasks, c, indent=4)
                        color(taskid=taskid, color=red, status='Access denied')
                        s.cookies = choose_cookie(region, taskid)
                        start()

                    elif 'fl-cart fl-cart__empty' in atc_post.text:
                        print (now() + Fore.RED + ' [TASK ' + taskid + '] [ERROR] Size out of stock')
                        tasks = json.load(open('web\\json\\tasks.json'))
                        task = tasks[int(taskid)]
                        task['color'] = red
                        task['status'] = 'Size out of stock'
                        with open('web\\json\\tasks.json', 'w') as c:
                            json.dump(tasks, c, indent=4)
                        color(taskid=taskid, color=red, status='Size out of stock')
                        time.sleep(5)
                        if is_random == True:
                            add_to_cart(variant_base, 'RANDOM')
                        else:
                            add_to_cart(variant_base, size)

                    elif 'fl-error-and-password-page--message' in atc_post.text:
                        print (now() + Fore.RED + ' [TASK ' + taskid + '] [ERROR] Invalid variant')
                        tasks = json.load(open('web\\json\\tasks.json'))
                        task = tasks[int(taskid)]
                        task['color'] = red
                        task['status'] = 'Invalid variant'
                        with open('web\\json\\tasks.json', 'w') as c:
                            json.dump(tasks, c, indent=4)
                        color(taskid=taskid, color=red, status='Invalid variant')
                        time.sleep(5)
                        if is_random == True:
                            add_to_cart(variant_base, 'RANDOM')
                        else:
                            add_to_cart(variant_base, size)

                    else:
                        print (now() + Fore.GREEN + ' [TASK ' + taskid + '] [STATUS] Succesfully added to cart!')
                        tasks = json.load(open('web\\json\\tasks.json'))
                        task = tasks[int(taskid)]
                        task['color'] = green
                        task['status'] = 'Succesfully added to cart!'
                        with open('web\\json\\tasks.json', 'w') as c:
                            json.dump(tasks, c, indent=4)
                        color(taskid=taskid, color=green, status='Succesfully added to cart!')
                        if mode == 'atc':
                            only_atc(title=title, price=price, image=image)
                        else:
                            ship(title=title, price=price, image=image)

                except Exception as e:
                    print (now() + Fore.RED + ' [TASK ' + taskid + '] [ERROR] Add to cart error -> ' + str(e))
                    tasks = json.load(open('web\\json\\tasks.json'))
                    task = tasks[int(taskid)]
                    task['color'] = red
                    task['status'] = 'ATC error'
                    with open('web\\json\\tasks.json', 'w') as c:
                        json.dump(tasks, c, indent=4)
                    color(taskid=taskid, color=red, status='ATC error')
                    tester()

            def start():
                try:
                    if proxylist != '':
                        tester()

                    if 'http' not in sku:
                        add_to_cart(sku, size)
                    else:
                        print (now() + Fore.YELLOW + ' [TASK ' + taskid + '] [STATUS] Getting product page...')
                        tasks = json.load(open('web\\json\\tasks.json'))
                        task = tasks[int(taskid)]
                        task['color'] = yellow
                        task['status'] = 'Getting product page...'
                        with open('web\\json\\tasks.json', 'w') as c:
                            json.dump(tasks, c, indent=4)
                        color(taskid=taskid, color=yellow, status='Getting product page...')
                        product = s.get(sku, headers=main_headers)

                        if product.status_code == 403 or 'denied' in product.text:
                            print (now() + Fore.RED + ' [TASK ' + taskid + '] [ERROR] Access denied')
                            tasks = json.load(open('web\\json\\tasks.json'))
                            task = tasks[int(taskid)]
                            task['color'] = red
                            task['status'] = 'Access denied'
                            with open('web\\json\\tasks.json', 'w') as c:
                                json.dump(tasks, c, indent=4)
                            color(taskid=taskid, color=red, status='Access denied')
                            
                            s.cookies = choose_cookie(region, taskid)
                            start()
                        
                        elif product.status_code == 503 or 'fl-downtime-page' in product.text:
                            print (now() + Fore.YELLOW + ' [TASK ' + taskid + '] [STATUS] In queue...')
                            tasks = json.load(open('web\\json\\tasks.json'))
                            task = tasks[int(taskid)]
                            task['color'] = yellow
                            task['status'] = 'In queue...'
                            with open('web\\json\\tasks.json', 'w') as c:
                                json.dump(tasks, c, indent=4)
                            color(taskid=taskid, color=yellow, status='In queue...')
                            time.sleep(delay)
                            start()
                        
                        elif product.status_code == 404:
                            print (now() + Fore.RED + ' [TASK ' + taskid + '] [ERROR] This product does not exist')
                            tasks = json.load(open('web\\json\\tasks.json'))
                            task = tasks[int(taskid)]
                            task['color'] = red
                            task['status'] = '404 not found'
                            with open('web\\json\\tasks.json', 'w') as c:
                                json.dump(tasks, c, indent=4)
                            color(taskid=taskid, color=red, status='404 not found')
                            time.sleep(5)
                            start()
                        
                        else:
                            if 'fl-product-details--summary--launch-notice__primary' in product.text:
                                print (now() + Fore.YELLOW + ' [TASK ' + taskid + '] [STATUS] Waiting for release...')
                                tasks = json.load(open('web\\json\\tasks.json'))
                                task = tasks[int(taskid)]
                                task['color'] = yellow
                                task['status'] = 'Waiting for release...'
                                with open('web\\json\\tasks.json', 'w') as c:
                                    json.dump(tasks, c, indent=4)
                                color(taskid=taskid, color=yellow, status='Waiting for release...')
                                time.sleep(5)
                                start()
                            else:
                                soup = BeautifulSoup(product.text, 'html.parser')
                                try:
                                    title = soup.find('span', {'itemprop':'name'}).text
                                    price = soup.find('meta', {'itemprop':'price'})['content']
                                    image = soup.find('meta', {'property':'og:image'})['content']
                                    variant_base = soup.find('div', {'class':'hide'})['data-owl-pdp-color']

                                    print (now() + Fore.GREEN + ' [TASK ' + taskid + '] [STATUS] Product found -> ' + title)
                                    tasks = json.load(open('web\\json\\tasks.json'))
                                    task = tasks[int(taskid)]
                                    task['color'] = green
                                    task['status'] = 'Product found: ' + title
                                    task['name'] = title
                                    with open('web\\json\\tasks.json', 'w') as c:
                                        json.dump(tasks, c, indent=4)
                                    color(taskid=taskid, color=green, status='Product found: ' + title)
                                    name(taskid=taskid, name=title)


                                except:
                                    print (now() + Fore.RED + ' [TASK ' + taskid + '] [ERROR] Error scraping product page')
                                    tasks = json.load(open('web\\json\\tasks.json'))
                                    task = tasks[int(taskid)]
                                    task['color'] = red
                                    task['status'] = 'Error scraping product page'
                                    with open('web\\json\\tasks.json', 'w') as c:
                                        json.dump(tasks, c, indent=4)
                                    color(taskid=taskid, color=red, status='Error scraping product page')
                                    start()

                                add_to_cart(variant_base, size, title=title, price=price, image=image)
                                input()
                
                except Exception as e:
                    print (now() + Fore.RED + ' [TASK ' + taskid + '] [ERROR] An error has occurred -> ' + str(e))
                    tasks = json.load(open('web\\json\\tasks.json'))
                    task = tasks[int(taskid)]
                    task['color'] = red
                    task['status'] = 'Unknown error'
                    with open('web\\json\\tasks.json', 'w') as c:
                        json.dump(tasks, c, indent=4)
                    color(taskid=taskid, color=red, status='Unknown error')
                    time.sleep(5)
                    start()
            
            start()
            time.sleep(10000000)



        except Exception as e:
            print (now() + Fore.RED + ' [TASK ' + taskid + '] [ERROR] An error has occurred -> ' + str(e))
            tasks = json.load(open('web\\json\\tasks.json'))
            task = tasks[int(taskid)]
            task['color'] = red
            task['status'] = 'Unknown error'
            with open('web\\json\\tasks.json', 'w') as c:
                json.dump(tasks, c, indent=4)
            color(taskid=taskid, color=red, status='Unknown error')
            time.sleep(5)
            start()
            

    if taskid == 'all':   
        profiles = json.load(open('web\\json\\profiles.json'))
        proxies = json.load(open('web\\json\\proxies.json'))
        config = json.load(open('web\\json\\config.json'))
        webhook_url = config['webhook']
        index = 0 
        for task in json.load(open('web\\json\\tasks.json')):
            region = task['region']
            sku = task['sku']
            size = task['size']
            proxylist = task['proxylist']
            profile = task['profile']
            mode = task['mode']

            threading.Thread(target=cop, args=(str(index), region, sku, size, proxylist, profile, mode)).start()
            index += 1
            time.sleep(1)
    else:
        profiles = json.load(open('web\\json\\profiles.json'))
        proxies = json.load(open('web\\json\\proxies.json'))
        config = json.load(open('web\\json\\config.json'))
        webhook_url = config['webhook']
        task = json.load(open('web\\json\\tasks.json'))[int(taskid)]
        region = task['region']
        sku = task['sku']
        size = task['size']
        proxylist = task['proxylist']
        profile = task['profile']
        mode = task['mode']

        threading.Thread(target=cop, args=(str(taskid), region, sku, size, proxylist, profile, mode)).start()


@eel.expose
def start_task(taskid):
    main(taskid=taskid)

@eel.expose
def start_all():
    main(taskid='all')

@eel.expose
def delete_all():
    open('web\\json\\tasks.json', 'w').write('[]')

@eel.expose
def delete_task(taskid):
    all_tasks = json.load(open('web\\json\\tasks.json'))
    all_tasks.remove(all_tasks[int(taskid)])
    with open('web\\json\\tasks.json', 'w') as c:
        json.dump(all_tasks, c, indent=4)

@eel.expose
def duplicate_task(taskid):
    all_tasks = json.load(open('web\\json\\tasks.json'))
    all_tasks.append(all_tasks[int(taskid)])
    with open('web\\json\\tasks.json', 'w') as c:
        json.dump(all_tasks, c, indent=4)

@eel.expose
def create_task(region, sku, size, proxylist, profile, mode, qty):
    n = 0
    tasks = json.load(open('web\\json\\tasks.json'))
    new_task = {
        'region':region,
        'name':'',
        'sku':sku,
        'size':size,
        'proxylist':proxylist,
        'profile':profile,
        'mode':mode,
        'color':'',
        'status':''
    }
    while True:
        if n == int(qty):
            break
        else:
            print ('1')
            tasks.append(new_task)
            n = n + 1

    with open('web\\json\\tasks.json', 'w') as c:
        json.dump(tasks, c, indent=4)

@eel.expose
def delete_proxylist(name):
    proxies = json.load(open('web\\json\\proxies.json'))
    proxies.pop(name)
    with open('web\\json\\proxies.json', 'w') as c:
        json.dump(proxies, c, indent=4)

@eel.expose
def create_proxylist(name, proxylist):
    if proxylist.endswith('\n') == True:
        proxylist = proxylist.rstrip('\n')
    
    proxies = json.load(open('web\\json\\proxies.json'))
    new_proxylist = {
        name:proxylist.split('\n')
    }
    proxies.update(new_proxylist)
    with open('web\\json\\proxies.json', 'w') as c:
        json.dump(proxies, c, indent=4)

@eel.expose
def delete_profile(name):
    profiles = json.load(open('web\\json\\profiles.json'))
    profiles.pop(name)
    with open('web\\json\\profiles.json', 'w') as c:
        json.dump(profiles, c, indent=4)

@eel.expose
def create_profile(profilename, name, surname, email, address, address2, house, city, zipcode, state, phone, cholder, cnumber, cexpiry, ccvc, birthday):
    profiles = json.load(open('web\\json\\profiles.json'))
    new_profile = {
        profilename: {
            "name": name,
            "surname": surname,
            "email": email,
            "address": address,
            "address2": address2,
            "house": house,
            "city": city,
            "zipcode": zipcode,
            "state": state,
            "phone": phone,
            "cholder": cholder,
            "cnumber": cnumber,
            "cexpiry": cexpiry,
            "ccvc": ccvc,
            "birthday": birthday
            }
    }

    profiles.update(new_profile)
    with open('web\\json\\profiles.json', 'w') as c:
        json.dump(profiles, c, indent=4)

@eel.expose
def test_webhook(webhook_url):
    try:
        webhook = DiscordWebhook(url=webhook_url, content='')
        embed = DiscordEmbed(title='FlowLocker Webhook Test', color=7700976)
        embed.set_footer(text='Flow Locker Webhook Test', icon_url='https://cdn.discordapp.com/attachments/654359760430170130/655535475947208704/static_logo.png')
        webhook.add_embed(embed)
        webhook.execute()
        config = json.load(open('web\\json\\config.json'))
        config['webhook'] = webhook_url
        with open('web\\json\\config.json', 'w') as c:
            json.dump(config, c, indent=4)
        eel.reload()
    except:
        eel.error('Webhook error')

@eel.expose
def set_delay(delay):
    try:
        int(delay) / 1000
        config = json.load(open('web\\json\\config.json'))
        config['delay'] = delay
        with open('web\\json\\config.json', 'w') as c:
            json.dump(config, c, indent=4)
        eel.reload()
    except:
        eel.error('Delay error')

@eel.expose
def clear_all():
    empty = {
        "dk": [],
        "co.uk": [],
        "de": [],
        "be": [],
        "fr": [],
        "es": [],
        "nl": [],
        "it": [],
        "se": [],
        "hk": [],
        "sg": [],
        "eu": [],
        "lu": []
    }

    with open('web\\json\\cookies.json', 'w') as c:
        json.dump(empty, c, indent=4)

@eel.expose
def cookie_generation(region, proxylist):
    
    def generate():
        def choose_proxy():
            if proxylist == '':
                proxy = ':::'
            else:
                proxies = json.load(open('web\\json\\proxies.json'))[proxylist]
                proxy = random.choice(proxies) + ':::'

            return proxy

        try:
            proxy = choose_proxy()
            proxysplit = proxy.split(':')

            PROXY_HOST = proxysplit[0]
            PROXY_PORT = proxysplit[1]
            PROXY_USER = proxysplit[2]
            PROXY_PASS = proxysplit[3]


            manifest_json = """
            {
                "version": "1.0.0",
                "manifest_version": 2,
                "name": "FlowMeshAkamai",
                "permissions": [
                    "proxy",
                    "tabs",
                    "unlimitedStorage",
                    "storage",
                    "<all_urls>",
                    "webRequest",
                    "webRequestBlocking"
                ],
                "background": {
                    "scripts": ["background.js"]
                },
                "minimum_chrome_version":"22.0.0"
            }
            """

            background_js = """
            var config = {
                    mode: "fixed_servers",
                    rules: {
                    singleProxy: {
                        scheme: "http",
                        host: "%s",
                        port: parseInt(%s)
                    },
                    bypassList: ["localhost"]
                    }
                };

            chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

            function callbackFn(details) {
                return {
                    authCredentials: {
                        username: "%s",
                        password: "%s"
                    }
                };
            }

            chrome.webRequest.onAuthRequired.addListener(
                        callbackFn,
                        {urls: ["<all_urls>"]},
                        ['blocking']
            );
            """ % (PROXY_HOST, PROXY_PORT, PROXY_USER, PROXY_PASS)


            chrome_options = webdriver.ChromeOptions()
            pluginfile = 'Proxy2.zip'
            with zipfile.ZipFile(pluginfile, 'w') as zp:
                zp.writestr("manifest.json", manifest_json)
                zp.writestr("background.js", background_js)
            chrome_options.add_extension(pluginfile)
            chrome_options.add_experimental_option('excludeSwitches', ['enable-logging'])
            chrome_options.add_argument('--disable-gpu')
            driver = webdriver.Chrome(options=chrome_options)

            try:
                os.remove('Proxy2.zip')
            except:
                pass

            validator = True

            while True:
                if validator == False:
                    break
                else:
                    driver.get('https://www.footlocker.' + region + '/')
                    cookievalue = driver.get_cookie('_abck')['value']
                    print (now() + Fore.YELLOW + '[STATUS] Validating akamai cookie...')
                    if '==~' in str(cookievalue):
                        with open('cookies.json', 'r+') as f:
                            cookies = json.load(f)
                            cookieslist = cookies[region]
                            cookieslist.append(cookievalue)
                            cookies[region] = (cookieslist)
                            f.seek(0)
                            json.dump(cookies, f, indent=4)
                            f.truncate()
                            print (now() + Fore.GREEN + '[STATUS] Akamai cookie added!')
                        driver.delete_all_cookies()
                    else:
                        print (now() + Fore.RED + '[ERROR] Invalid akamai cookie, changing proxies...')
                        driver.quit()
                        generate()
        except:
            return
    
    threading.Thread(target=generate).start()

eel.start('tasks.html', disable_cache=True)
