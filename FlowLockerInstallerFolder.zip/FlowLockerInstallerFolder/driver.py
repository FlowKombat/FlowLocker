import os, zipfile, requests, random
from selenium import webdriver

main_headers = {
    'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-encoding':'gzip, deflate, br',
    'accept-language':'it-IT,it;q=0.9,en-US;q=0.8,en;q=0.7',
    'upgrade-insecure-requests':'1',
    'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36'
}

def driver(proxylist=None, region=None):

    if proxylist:

        s = requests.Session()
        def choose_proxy(proxylist):
            proxy = random.choice(proxylist)

            if len(proxy.split(':')) == 2:

                proxy = {
                'http': 'http://' + proxy,
                'https': 'http://' + proxy
                }

            elif len(proxy.split(':')) == 4:

                prx = proxy.split(':')

                proxy = {
                'http': 'http://' + prx[2] + ':' + prx[3] + '@' + prx[0] + ':' + prx[1],
                'https': 'https://' + prx[2] + ':' + prx[3] + '@' + prx[0] + ':' + prx[1]
                }

            return proxy

        def tester():
            s.proxies = choose_proxy(proxylist)
            try:
                test = s.get('https://www.footlocker.' + region, headers=main_headers)
                if test.status_code not in (302, 200, 503, 201):
                    tester()

            except:
                tester()

        proxy = random.choice(proxylist) + ':::'
        PROXY_HOST = proxy.split(':')[0]
        PROXY_PORT = proxy.split(':')[1]
        PROXY_USER = proxy.split(':')[2]
        PROXY_PASS = proxy.split(':')[3]


        manifest_json = """
        {
            "version": "1.0.0",
            "manifest_version": 2,
            "name": "Chrome Proxy",
            "permissions": [
                "proxy",
                "tabs",
                "unlimitedStorage",
                "storage",
                "<all_urls>",
                "webRequest",
                "webRequestBlocking"
            ],
            "background": {
                "scripts": ["background.js"]
            },
            "minimum_chrome_version":"22.0.0"
        }
        """

        background_js = """
        var config = {
                mode: "fixed_servers",
                rules: {
                singleProxy: {
                    scheme: "http",
                    host: "%s",
                    port: parseInt(%s)
                },
                bypassList: ["localhost"]
                }
            };

        chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

        function callbackFn(details) {
            return {
                authCredentials: {
                    username: "%s",
                    password: "%s"
                }
            };
        }

        chrome.webRequest.onAuthRequired.addListener(
                    callbackFn,
                    {urls: ["<all_urls>"]},
                    ['blocking']
        );
        """ % (PROXY_HOST, PROXY_PORT, PROXY_USER, PROXY_PASS)


        chrome_options = webdriver.ChromeOptions()
        pluginfile = 'Proxy1.zip'
        with zipfile.ZipFile(pluginfile, 'w') as zp:
            zp.writestr("manifest.json", manifest_json)
            zp.writestr("background.js", background_js)
        chrome_options.add_extension(pluginfile)
        chrome_options.add_experimental_option('excludeSwitches', ['enable-logging'])
        chrome_options.add_argument('--disable-gpu')
        browser = webdriver.Chrome(options=chrome_options)
        
        return browser

    else:
        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_experimental_option('excludeSwitches', ['enable-logging'])
        chrome_options.add_argument('--disable-gpu')
        browser = webdriver.Chrome(options=chrome_options)
        return browser