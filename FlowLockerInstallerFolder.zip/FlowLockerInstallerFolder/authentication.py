from requests import post
from json import loads, load, dump
from uuid import getnode
from datetime import datetime
from colorama import Fore, init
import sys
init(convert=True, autoreset=True)

def now():
    now = '[{}] '.format((str(datetime.now())))
    return now

class authentication():

    def __init__(self, key):
        self.key = key
        self.mac = hex(getnode())

    def auth(self):

        if self.key == '':
            print (now() + Fore.GREEN + '[CHOICE] Key -> ', end='')
            self.key = input()

            with open('web\\json\\config.json', 'r+') as f:
                configpage = load(f)
                configpage['key'] = self.key
                f.seek(0)
                dump(configpage, f, indent=4)
                f.truncate()
            
        status = post('https://flowlocker.herokuapp.com//api/bot/activate', data={'key':self.key, 'mac_id':self.mac})
        status = loads(status.text)

        if status['status'] == 'not found':
            print (now() + Fore.RED + '[ERROR] Invalid key!')
            input()
            sys.exit()

        elif status['status'] == 'successfully activated':
            print (now() + Fore.GREEN + '[STATUS] Valid key!')
        else:
            if status['mac_id'] == self.mac:
                print (now() + Fore.GREEN + '[STATUS] Valid key!')
            else:
                print (now() + Fore.RED + '[ERROR] The key is binded to another pc!')
                input()
                sys.exit()
